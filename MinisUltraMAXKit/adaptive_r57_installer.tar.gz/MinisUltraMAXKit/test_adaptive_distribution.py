"""Independent clean-runner distribution and anti-tamper tests."""
import pathlib
import shutil
import subprocess
import tempfile
import unittest

HERE = pathlib.Path(__file__).resolve().parent


class DistributionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        for name in ('apply_adaptive_r57.py', 'adaptive_core_source.tar.gz'):
            shutil.copy2(HERE/name, self.root/name)

    def run_installer(self):
        return subprocess.run(['python3','apply_adaptive_r57.py','--unpack'],
                              cwd=self.root, text=True, capture_output=True)

    def test_fresh_clean_runner_unpacks_and_passes_eight_existing_tests(self):
        got = self.run_installer()
        self.assertEqual(got.returncode,0,got.stderr)
        self.assertTrue((self.root/'adaptive_engineer.py').is_file())
        got = subprocess.run(['python3','-m','unittest','test_adaptive_engineer','-q'],
                             cwd=self.root,text=True,capture_output=True)
        self.assertEqual(got.returncode,0,got.stderr)

    def test_existing_source_cannot_be_overwritten(self):
        self.assertEqual(self.run_installer().returncode,0)
        result = self.run_installer()
        self.assertEqual(result.returncode,2)
        self.assertIn('refuse to overwrite',result.stderr)

    def test_modified_source_archive_is_rejected(self):
        with (self.root/'adaptive_core_source.tar.gz').open('ab') as f:
            f.write(b'changed')
        result = self.run_installer()
        self.assertEqual(result.returncode,2)
        self.assertIn('digest mismatch',result.stderr)
        self.assertFalse((self.root/'adaptive_engineer.py').exists())


if __name__=='__main__':
    unittest.main()
