#!/usr/bin/env python3
"""Fail-closed R5.7 overlay, applied after the pinned R5.6 native patch.

No original app identity, model settings, stable source, private projects or user
workspace are changed. Run --unpack once before Python test discovery.
"""
import argparse
import pathlib
import shutil
import tarfile
import sys

ROOT = pathlib.Path(__file__).resolve().parent
ARCHIVE = ROOT / 'adaptive_core_source.tar.gz'


def unpack():
    if not ARCHIVE.is_file():
        raise RuntimeError('NO-GO: audited R5.7 source archive missing')
    import hashlib
    actual = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    if actual != 'a86c000ac07421ebb8fdfff58790da21652d1e789610b89122a11aabb1015c6f':
        raise RuntimeError('NO-GO: R5.7 source archive digest mismatch')
    permitted = {'adaptive_engineer.py', 'test_adaptive_engineer.py'}
    with tarfile.open(ARCHIVE, 'r:gz') as t:
        members = t.getmembers()
        if {x.name for x in members} != permitted or any(not x.isfile() or x.size > 40_000 for x in members):
            raise RuntimeError('NO-GO: unexpected R5.7 archive contents')
        for member in members:
            target = ROOT / pathlib.Path(member.name).name
            if target.exists() or target.is_symlink():
                raise RuntimeError('NO-GO: refuse to overwrite R5.7 source')
            with t.extractfile(member) as source, open(target, 'xb') as dest:
                shutil.copyfileobj(source, dest)
    return 'R5.7 adaptive source extracted and validated'


def substitute_once(data, old, new, label):
    if data.count(old) != 1:
        raise RuntimeError('NO-GO: drift detected in ' + label)
    return data.replace(old, new, 1)


def integrate(project):
    project = pathlib.Path(project)
    skills = project / 'src/ios/default_mount/var/minis/skills/minis-dev-ultra/SKILL.md'
    shell = project / 'src/ios/default_mount/usr/local/bin/minis-adapt'
    library = project / 'src/ios/default_mount/usr/local/lib/minis-dev-ultra/adaptive_engineer.py'
    swift = project / 'src/ios/Agent/Chat/AIChatViewModel+SlashCommands.swift'
    sources = ROOT / 'adaptive_engineer.py'
    wrapper = ROOT / 'runtime/minis-adapt'
    if not all(p.is_file() for p in (skills, swift, sources, wrapper)):
        raise RuntimeError('NO-GO: R5.6 overlay and original source are required')
    if shell.exists() or library.exists():
        raise RuntimeError('NO-GO: R5.7 app target already exists')
    code = swift.read_text('utf-8')
    code = substitute_once(code,
        '        SlashCommand(id: "devauto",',
        '        SlashCommand(id: "devadapt", icon: "brain.head.profile", title: "Adaptive Engineer", subtitle: "Evidence-aware multi-language diagnosis and planning"),\n        SlashCommand(id: "devauto",',
        'slash menu')
    code = substitute_once(code,
        '        case "devauto":',
        '        case "devadapt":\n'
        '            inputText = "/minis-dev-ultra Adaptive Engineer: discover the actual project directory, then run minis-adapt inspect --project PATH and minis-adapt plan --project PATH --goal USER_GOAL. Read matching evidence and error diagnoses, choose the next smallest falsifiable step across any language and toolchain, then execute authorized source edits with existing verified tools, tests and CI; call minis-adapt learn only for evidence-backed outcomes. Do not rely on keyword workflow alone; dynamically adapt to actual source and runtime evidence. Do not repeat disproved same-version methods, force a model tier, or invent an IPA/device pass. " + inputText\n'
        '            requestComposerFocusSignal.send()\n'
        '        case "devauto":',
        'slash dispatch')
    shell.parent.mkdir(parents=True, exist_ok=True)
    library.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(wrapper, shell)
    shell.chmod(0o755)
    shutil.copy2(sources, library)
    library.chmod(0o644)
    with skills.open('a', encoding='utf-8') as f:
        f.write('\n\n## R5.7 AdaptiveCore (real offline execution policy)\n'
                'On new development tasks use `minis-adapt inspect --project PATH` and '
                '`minis-adapt plan --project PATH --goal "GOAL"` before resuming. '
                'Its ecosystem scan, exact-version evidence ledger, error classifications and '
                'settings (history/dedupe/auto_tests) are actually executed by Python. '
                'Use `minis-adapt learn --project PATH --goal GOAL --status verified_static|verified_device|disproved|hypothesis --evidence FILE --finding DESCRIPTION` '
                'for real outcomes; this does not ingest the contents of old chats automatically. '
                'The optional test preference is not a permission grant: execute tests only with '
                'the existing bounded test runner and user authorization. '
                'This R5.7 tool does not autonomously call an LLM, modify code, install a tweak, '
                'respring, publish, or claim device verification.\n')
    swift.write_text(code, encoding='utf-8')
    return 'R5.7 AdaptiveCore installed into separate R5.6 source overlay with /devadapt'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--unpack', action='store_true')
    p.add_argument('--integrate')
    a = p.parse_args()
    if a.unpack == bool(a.integrate):
        p.error('choose one of --unpack or --integrate')
    try:
        print(unpack() if a.unpack else integrate(a.integrate))
    except (OSError, RuntimeError, tarfile.TarError) as e:
        print('NO-GO:', e, file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
