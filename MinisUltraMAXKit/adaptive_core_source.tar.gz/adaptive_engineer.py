#!/usr/bin/env python3
"""R5.7 AdaptiveCore: offline project intelligence + evidence-bound next-step policy.

No model calls, project code execution, edits, package installs, network or uploads.
It complements existing agent/model and bounded repair/test tools, not replaces them.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

VERSION = "0.1.0"
CAP = 500
VALID = {"verified_static", "verified_device", "disproved", "hypothesis"}
SECRET = re.compile(r"(?i)(?:gh[pousr]_[a-z0-9_]{20,}|github_pat_[a-z0-9_]{20,}|sk-[a-z0-9_-]{16,}|-----BEGIN [A-Z ]+ PRIVATE KEY-----)")
SUPPORTED = {
    "SwiftPM": ("Package.swift", "swift", "swift test"),
    "Xcode": ("*.xcodeproj", "xcodebuild", "xcodebuild test [needs scheme and destination]"),
    "Theos": ("control", "make", "minis-deb doctor (inspect Makefile before build)"),
    "Rust": ("Cargo.toml", "cargo", "cargo test"),
    "Go": ("go.mod", "go", "go test ./..."),
    "Python": ("pyproject.toml", "python3", "python3 -m unittest discover"),
    "Node": ("package.json", "node", "review package scripts before npm test"),
    "CMake": ("CMakeLists.txt", "cmake", "cmake --build [review build dir]"),
    "Gradle": ("settings.gradle", "java", "review ./gradlew and build target"),
    "GradleKts": ("settings.gradle.kts", "java", "review ./gradlew and build target"),
    "Maven": ("pom.xml", "mvn", "mvn test"),
    "Flutter": ("pubspec.yaml", "flutter", "flutter test"),
    "DotNet": ("*.sln", "dotnet", "dotnet test"),
}
ERRORS = [
    ("missing_sdk", r"(?:SDK not found|iPhoneOS SDK|SDKROOT.*not|unable to find sdk)", "Inspect installed SDK and TARGET; never invent or download a licensed SDK"),
    ("compiler_diagnostic", r"(?:error:.*(?:cannot find|use of undeclared|no member|type mismatch|expected)|fatal error:.*file not found)", "Read the first compiler error, affected source and related declarations"),
    ("linker_missing_symbol", r"(?:undefined symbol|Undefined symbols for architecture|ld: symbol\(s\) not found)", "Check symbol ownership, ABI, link order and deployment target"),
    ("swift_abi", r"(?:swift_retain|witness table|pointer authentication|PAC failure|EXC_BAD_ACCESS)", "Correlate exact Mach-O UUID, callsite, owner lifetime and same-run trace"),
    ("test_failure", r"(?:FAILED \(failures=|AssertionError|Test failed|FAIL: test_)", "Isolate the failing test and one reproducible source path"),
    ("authorization", r"(?:403 Forbidden|permission denied|not authorized|HTTP 401)", "Check the actual permission or account flow; do not retry blindly"),
    ("tool_missing", r"(?:command not found|No such file or directory: .*(?:clang|swift|python|xcodebuild))", "Check tool location and compatible environment before attempting installation"),
]


def clean(s, n=240):
    return SECRET.sub("[REDACTED]", str(s)).strip()[:n]


def digest(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def root_of(value):
    p = Path(value).expanduser().absolute()
    if not p.is_dir() or p.is_symlink():
        raise ValueError("project must be an existing non-symlink directory")
    return p


def state_path(project):
    configured = os.environ.get("MINIS_ADAPT_STATE")
    base = Path(configured).expanduser() if configured else Path.home() / ".local/state/minis-dev-ultra/adaptive"
    if base.is_symlink():
        raise ValueError("state root must not be a symlink")
    key = hashlib.sha256(str(project).encode("utf-8")).hexdigest()[:24]
    return base / (key + ".json")


def read_state(project):
    p = state_path(project)
    if not p.exists():
        return {"schema": 1, "project": str(project), "settings": {"history": True, "dedupe": True, "auto_tests": False}, "evidence": []}
    if p.is_symlink() or p.stat().st_size > 2_000_000:
        raise ValueError("unsafe state file")
    value = json.loads(p.read_text("utf-8"))
    if value.get("schema") != 1 or value.get("project") != str(project):
        raise ValueError("state identity does not match project")
    if not isinstance(value.get("settings"), dict) or not isinstance(value.get("evidence"), list):
        raise ValueError("malformed state")
    return value


def persist(project, value):
    p = state_path(project)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.is_symlink():
        raise ValueError("refusing linked state file")
    fd, tmp = tempfile.mkstemp(prefix=".adaptive-", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False, sort_keys=True, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def identity(project, target):
    if target:
        p = Path(target).expanduser().absolute()
        if p.is_symlink() or not p.is_file() or p.stat().st_size > 1_000_000_000:
            raise ValueError("target must be a real local file <= 1 GB")
        return {"kind": "artifact_sha256", "sha256": digest(p)}
    if (project / ".git").is_dir() and shutil.which("git"):
        r = subprocess.run(["git", "-C", str(project), "rev-parse", "HEAD"], capture_output=True, text=True, timeout=6)
        if r.returncode == 0 and re.fullmatch(r"[a-f0-9]{40,64}", r.stdout.strip()):
            dirty = subprocess.run(["git", "-C", str(project), "status", "--porcelain", "--untracked-files=no"], capture_output=True, text=True, timeout=6)
            if dirty.returncode == 0:
                return {"kind": "git_commit", "sha256": r.stdout.strip(), "dirty": bool(dirty.stdout.strip())}
    # Deterministic fallback for unversioned projects. Bounded source scan, no execution.
    h = hashlib.sha256()
    count = 0
    ignored = {".git", "node_modules", "vendor", "build", ".build", ".minis", "dist", ".venv"}
    for directory, subdirs, files in os.walk(project, followlinks=False):
        subdirs[:] = sorted(d for d in subdirs if d not in ignored and not (Path(directory) / d).is_symlink())
        for name in sorted(files):
            if count >= 300:
                break
            path = Path(directory) / name
            if path.is_symlink() or path.suffix.lower() not in {".swift", ".mm", ".m", ".py", ".c", ".cpp", ".h", ".js", ".ts", ".go", ".rs", ".java", ".kt", ".json", ".toml"}:
                continue
            stat = path.stat()
            h.update(str(path.relative_to(project)).encode())
            h.update(str(stat.st_size).encode())
            if stat.st_size <= 2_000_000:
                h.update(bytes.fromhex(digest(path)))
            count += 1
        if count >= 300:
            break
    return {"kind": "source_tree", "sha256": h.hexdigest(), "files": count}


def detect(project):
    found = []
    for name, (marker, tool, recommendation) in SUPPORTED.items():
        present = bool(list(project.glob(marker))[:1]) if "*" in marker else (project / marker).exists()
        if name == "Theos":
            present = present and (project / "Makefile").is_file()
        if not present:
            continue
        found.append({"ecosystem": name, "tool": tool, "tool_available": bool(shutil.which(tool)), "suggested_check": recommendation})
    if not found and (list(project.glob("test_*.py")) or list((project / "tests").glob("test_*.py")) if (project / "tests").is_dir() else list(project.glob("test_*.py"))):
        found.append({"ecosystem": "Python", "tool": "python3", "tool_available": bool(shutil.which("python3")), "suggested_check": "python3 -m unittest discover"})
    return found


def triage(log_path):
    if not log_path:
        return []
    p = Path(log_path).expanduser().absolute()
    if p.is_symlink() or not p.is_file() or p.stat().st_size > 10_000_000:
        raise ValueError("log must be regular file <= 10 MB")
    content = p.read_text("utf-8", errors="replace")
    hits = []
    for category, pattern, next_step in ERRORS:
        if re.search(pattern, content, re.I):
            hits.append({"category": category, "next_step": next_step})
    return hits[:4]


def normalized(goal):
    return " ".join(clean(goal, 180).casefold().split())


def decide(project, state, goal, target, logfile):
    current = identity(project, target)
    matches = []
    if state["settings"].get("history", True):
        matches = [r for r in state["evidence"] if r.get("subject") == normalized(goal) and r.get("identity", {}).get("sha256") == current["sha256"] and r.get("identity", {}).get("kind") == current["kind"]]
    newest = matches[-1] if matches else None
    diagnosis = triage(logfile)
    recommendation = "Inspect relevant source/call chain and choose a smallest falsifiable experiment"
    status = "investigate"
    if newest and newest["status"] in {"verified_static", "verified_device"}:
        status = "reuse_verified" if state["settings"].get("dedupe", True) else "review_prior_evidence"
        recommendation = "Reuse the exact same-version evidence; investigate only the next unproven requirement"
    elif newest and newest["status"] == "disproved":
        status = "blocked_repeat_failure" if state["settings"].get("dedupe", True) else "review_failed_experiment"
        recommendation = "Do not retry the same hypothesis with identical input; identify a changed premise or new evidence"
    elif diagnosis:
        status = "diagnose_first"
        recommendation = diagnosis[0]["next_step"]
    elif not detect(project):
        status = "unknown_environment"
        recommendation = "Inspect files, toolchain and target; no known build/test runner established"
    return {"status": status, "goal": clean(goal), "identity": current,
            "ecosystems": detect(project), "diagnosis": diagnosis,
            "prior_evidence": newest, "next_action": recommendation,
            "test_execution": "not_executed", "model_calls": 0,
            "device_verified_now": False,
            "autopilot": "python3 /usr/local/lib/minis-dev-ultra/autopilot.py plan --project PROJECT (review before --execute)"}


def handle(args):
    project = root_of(args.project)
    state = read_state(project)
    if args.command == "inspect":
        return {"version": VERSION, "project": str(project), "identity": identity(project, args.target), "ecosystems": detect(project), "settings": state["settings"], "evidence_count": len(state["evidence"])}
    if args.command == "plan":
        if not args.goal.strip():
            raise ValueError("goal required")
        return decide(project, state, args.goal, args.target, args.log)
    if args.command == "settings":
        if args.set_key:
            if args.set_key not in {"history", "dedupe", "auto_tests"}:
                raise ValueError("unknown setting")
            state["settings"][args.set_key] = args.value == "on"
            persist(project, state)
        return {"settings": state["settings"], "note": "auto_tests is a consent preference only; no tests are started by this tool"}
    if args.command == "history":
        return {"records": state["evidence"][-30:], "count": len(state["evidence"])}
    if args.command == "learn":
        if args.status not in VALID or not normalized(args.goal):
            raise ValueError("status and subject required")
        evidence_sha = None
        if args.evidence:
            p = Path(args.evidence).expanduser().absolute()
            if p.is_symlink() or not p.is_file() or p.stat().st_size > 50_000_000:
                raise ValueError("evidence must be a real local file <= 50 MB")
            evidence_sha = digest(p)
        if args.status != "hypothesis" and evidence_sha is None:
            raise ValueError("verified/disproved claims require real evidence file")
        rec = {"subject": normalized(args.goal), "status": args.status,
               "identity": identity(project, args.target), "evidence_sha256": evidence_sha,
               "finding": clean(args.finding, 300)}
        if any(x == rec for x in state["evidence"]):
            return {"status": "already_recorded", "record": rec}
        state["evidence"].append(rec)
        state["evidence"] = state["evidence"][-CAP:]
        persist(project, state)
        return {"status": "recorded", "record": rec}
    raise ValueError("unsupported command")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Offline evidence-based adaptive development planning")
    sub = parser.add_subparsers(dest="command", required=True)
    for c in ("inspect", "plan", "learn", "history", "settings"):
        subp = sub.add_parser(c)
        subp.add_argument("--project", required=True)
        if c in {"inspect", "plan", "learn"}:
            subp.add_argument("--target")
        if c in {"plan", "learn"}:
            subp.add_argument("--goal", required=True)
        if c == "plan":
            subp.add_argument("--log")
        if c == "learn":
            subp.add_argument("--status", required=True, choices=sorted(VALID))
            subp.add_argument("--evidence")
            subp.add_argument("--finding", required=True)
        if c == "settings":
            subp.add_argument("--set-key")
            subp.add_argument("--value", choices=["on", "off"], default="off")
    args = parser.parse_args(argv)
    try:
        result = handle(args)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
        return 0
    except (ValueError, OSError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "NO-GO", "reason": clean(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
