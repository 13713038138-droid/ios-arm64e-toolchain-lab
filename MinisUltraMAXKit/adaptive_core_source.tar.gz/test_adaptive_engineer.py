"""Regression tests for R5.7 AdaptiveCore with actual temp project artifacts."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import adaptive_engineer as a


class AdaptiveTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.p = Path(self.t.name) / "project"
        self.p.mkdir()
        self.state = Path(self.t.name) / "state"
        self.old = os.environ.get("MINIS_ADAPT_STATE")
        os.environ["MINIS_ADAPT_STATE"] = str(self.state)
        self.addCleanup(self.restore)

    def restore(self):
        if self.old is None:
            os.environ.pop("MINIS_ADAPT_STATE", None)
        else:
            os.environ["MINIS_ADAPT_STATE"] = self.old

    def cli(self, *argv):
        code = a.main([*argv, "--project", str(self.p)])
        self.assertEqual(code, 0)

    def test_multilanguage_detection(self):
        (self.p / "Cargo.toml").write_text("[package]\nname='test'")
        (self.p / "Package.swift").write_text("// SwiftPM")
        (self.p / "Makefile").write_text("all: ; @true")
        (self.p / "control").write_text("Package: test")
        kinds = {v["ecosystem"] for v in a.detect(self.p)}
        self.assertEqual(kinds, {"SwiftPM", "Rust", "Theos"})

    def test_evidence_dedup_and_reuse(self):
        (self.p / "x.swift").write_text("A")
        (self.p / "proof.log").write_text("verified machine code")
        ns = a.main(["learn", "--project", str(self.p), "--goal", "Ring state binding", "--status", "verified_static", "--finding", "Verified callsites", "--evidence", str(self.p / "proof.log")])
        self.assertEqual(ns, 0)
        self.assertEqual(a.decide(self.p, a.read_state(self.p), "Ring state binding", None, None)["status"], "reuse_verified")
        (self.p / "x.swift").write_text("B")
        self.assertNotEqual(a.decide(self.p, a.read_state(self.p), "Ring state binding", None, None)["status"], "reuse_verified")

    def test_binary_identity_prevents_cross_version_reuse(self):
        f = self.p / "t.dylib"
        f.write_bytes(b"binaryA")
        proof = self.p / "proof.txt"
        proof.write_text("result negative")
        a.main(["learn", "--project", str(self.p), "--target", str(f), "--goal", "same hook", "--status", "disproved", "--finding", "bad call", "--evidence", str(proof)])
        self.assertEqual(a.decide(self.p, a.read_state(self.p), "same hook", str(f), None)["status"], "blocked_repeat_failure")
        f.write_bytes(b"binaryB")
        self.assertNotEqual(a.decide(self.p, a.read_state(self.p), "same hook", str(f), None)["status"], "blocked_repeat_failure")

    def test_rejects_unproven_success(self):
        rc = a.main(["learn", "--project", str(self.p), "--goal", "success", "--status", "verified_device", "--finding", "claim"])
        self.assertEqual(rc, 2)
        self.assertEqual(a.read_state(self.p)["evidence"], [])

    def test_settings_have_effect(self):
        evidence = self.p / "proof.log"
        evidence.write_text("some evidence")
        a.main(["learn", "--project", str(self.p), "--goal", "hook", "--status", "disproved", "--evidence", str(evidence), "--finding", "bad"])
        a.main(["settings", "--project", str(self.p), "--set-key", "dedupe", "--value", "off"])
        self.assertEqual(a.decide(self.p, a.read_state(self.p), "hook", None, None)["status"], "review_failed_experiment")
        a.main(["settings", "--project", str(self.p), "--set-key", "history", "--value", "off"])
        self.assertNotEqual(a.decide(self.p, a.read_state(self.p), "hook", None, None)["status"], "review_failed_experiment")

    def test_failure_triage_redacts_logs(self):
        f = self.p / "build.log"
        f.write_text("my secret sk-abcdefghijklmnopqrstu ERROR: undefined symbols for architecture arm64e")
        hits = a.triage(str(f))
        self.assertEqual(hits[0]["category"], "linker_missing_symbol")
        self.assertNotIn("sk-", json.dumps(hits))

    def test_state_file_not_in_project_and_duplicate_is_idempotent(self):
        proof = self.p / "evidence.txt"
        proof.write_text("proof")
        args = ["learn", "--project", str(self.p), "--goal", "story", "--status", "verified_static", "--finding", "done", "--evidence", str(proof)]
        self.assertEqual(a.main(args), 0)
        self.assertEqual(a.main(args), 0)
        self.assertEqual(len(a.read_state(self.p)["evidence"]), 1)
        self.assertNotIn(".minis", [x.name for x in self.p.iterdir()])

    def test_no_execution_of_source_code(self):
        (self.p / "pyproject.toml").write_text("[build-system]\nrequires=[]")
        marker = self.p / "executed.txt"
        (self.p / "test_bad.py").write_text(f"from pathlib import Path\nPath({str(marker)!r}).write_text('executed')")
        self.assertEqual(a.main(["plan", "--project", str(self.p), "--goal", "help"]), 0)
        self.assertFalse(marker.exists())


if __name__ == "__main__":
    unittest.main()
